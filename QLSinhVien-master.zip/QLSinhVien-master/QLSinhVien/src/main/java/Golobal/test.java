package Golobal;

public class test {
	private static String user;
    
	public static String getUser() {
		return user;
	}

	public static void setUser(String user) {
		test.user = user;
	}

	

	
}
